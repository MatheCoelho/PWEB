module.exports = function (app) {
  app.get('/informacao/professores', (req, res) => {
    //res.render('informacao/professores');
    const sql = require('mssql');

    const sqlConfig = {
      user: 'BD2313045',
      password: 'NadyMathe8',
      database: 'BD',
      server: 'APOLO',
      options: {
        encrypt: false,
        trustServerCerticate: true,
      }
    }

    async function getProfessores(){
      try {
        const pool = await sql.connect(sqlConfig);

        const results = await pool.request().query('SELECT * FROM PROFESSORES')

        //res.json(results.recordset);

        res.render('informacao/professores',{profs: results.recordset})

      } catch (err) {
        console.log(err)
      }
    }
    getProfessores();
  });
};
